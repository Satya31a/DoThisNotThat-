import React from 'react';

const AdBanner = ({ position = 'top', className = '' }) => {
  return (
    <div className={`ad-banner ${className} bg-gray-100 border-2 border-dashed border-gray-300 p-4 text-center`}>
      <div className="text-gray-500 text-sm mb-2">Advertisement</div>
      <div className="bg-gradient-to-r from-blue-500 to-green-500 text-white p-6 rounded-lg">
        <h3 className="text-lg font-bold mb-2">Google AdSense Placeholder</h3>
        <p className="text-sm">
          {position === 'top' && 'Top Banner Ad - 728x90'}
          {position === 'inline' && 'Inline Ad - 300x250'}
          {position === 'bottom' && 'Bottom Sticky Ad - 320x50'}
        </p>
        <div className="text-xs mt-2 opacity-75">
          Replace this with actual Google AdSense code
        </div>
      </div>
    </div>
  );
};

export default AdBanner;

