import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Search, Share2, TrendingUp, Zap, Heart, MessageCircle } from 'lucide-react'
import { decisionCards, trendingCards, categories, motivationalQuotes, shareMessages } from './decision_cards_data.js'
import AdBanner from './components/AdBanner.jsx'
import './App.css'

function App() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [filteredCards, setFilteredCards] = useState(decisionCards)
  const [currentQuote, setCurrentQuote] = useState(0)
  const [showSubmissionForm, setShowSubmissionForm] = useState(false)
  const [userSubmission, setUserSubmission] = useState({ doThis: '', notThat: '', why: '' })

  useEffect(() => {
    const quoteInterval = setInterval(() => {
      setCurrentQuote((prev) => (prev + 1) % motivationalQuotes.length)
    }, 4000)
    return () => clearInterval(quoteInterval)
  }, [])

  useEffect(() => {
    let filtered = decisionCards
    
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(card => card.category === selectedCategory)
    }
    
    if (searchQuery) {
      filtered = filtered.filter(card => 
        card.doThis.toLowerCase().includes(searchQuery.toLowerCase()) ||
        card.notThat.toLowerCase().includes(searchQuery.toLowerCase()) ||
        card.why.toLowerCase().includes(searchQuery.toLowerCase())
      )
    }
    
    setFilteredCards(filtered)
  }, [searchQuery, selectedCategory])

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      // Trigger search animation
      const searchBtn = document.querySelector('.search-btn')
      searchBtn?.classList.add('animate-pulse')
      setTimeout(() => searchBtn?.classList.remove('animate-pulse'), 1000)
    }
  }

  const shareCard = (card, platform) => {
    const url = encodeURIComponent(window.location.href)
    const text = encodeURIComponent(card.shareText)
    
    let shareUrl = ''
    switch(platform) {
      case 'whatsapp':
        shareUrl = `https://wa.me/?text=${text} ${url}`
        break
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${text}&url=${url}`
        break
      case 'instagram':
        // Instagram doesn't support direct sharing, so copy to clipboard
        navigator.clipboard.writeText(`${card.shareText} ${window.location.href}`)
        alert('Link copied! Paste it on Instagram 📱')
        return
    }
    
    if (shareUrl) {
      window.open(shareUrl, '_blank')
    }
  }

  const submitUserConfusion = (e) => {
    e.preventDefault()
    // In a real app, this would send to backend
    alert('Thanks for your confusion! We\'ll add it soon 🔥')
    setUserSubmission({ doThis: '', notThat: '', why: '' })
    setShowSubmissionForm(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-blue-50 to-green-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-electric-blue">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-black electric-blue mb-2">
              DoThisNotThat.in
            </h1>
            <div className="text-lg md:text-xl text-gray-600 mb-4">
              <span className="neon-green font-bold">Still Confused?</span> Let Us Tell You What's Best. <span className="font-black">Period. 🔥</span>
            </div>
            <p className="text-md md:text-lg font-bold text-gray-700">
              <span className="electric-blue">Instant answers.</span> <span className="neon-green">Brutally clear.</span> <span className="text-pink-500">Shareable AF.</span>
            </p>
          </div>
        </div>
      </header>

      {/* Motivational Quote Banner */}
      <div className="bg-electric-blue text-white py-3 text-center">
        <p className="text-lg font-bold animate-pulse">
          {motivationalQuotes[currentQuote]}
        </p>
      </div>

      {/* Search Section */}
      <section className="container mx-auto px-4 py-8">
        <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
          <div className="relative">
            <Input
              type="text"
              placeholder="e.g. MBA vs Startup | Gym vs Home Workout | Mac vs Windows"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="text-lg py-4 pr-16 border-2 border-electric-blue focus:border-neon-green"
            />
            <Button 
              type="submit"
              className="search-btn absolute right-2 top-1/2 transform -translate-y-1/2 bg-neon-green hover:bg-green-400 text-black font-bold bounce-animation sparkle-effect"
            >
              🔥 Show Me Now
            </Button>
          </div>
        </form>
        
        {/* Top Banner Ad */}
        <div className="mt-8">
          <AdBanner position="top" />
        </div>
      </section>

      {/* Categories */}
      <section className="container mx-auto px-4 py-4">
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {categories.map(category => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              onClick={() => setSelectedCategory(category.id)}
              className={`${selectedCategory === category.id ? 'bg-electric-blue' : 'hover:bg-electric-blue hover:text-white'} transition-all duration-300`}
            >
              {category.emoji} {category.name}
            </Button>
          ))}
        </div>
      </section>

      {/* Trending Section */}
      <section className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-black mb-4">
            🔥 <span className="neon-green">Trending Confusions</span> Today
          </h2>
          <p className="text-gray-600">What everyone's asking right now</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {trendingCards.map(card => (
            <Card key={card.id} className="hover:shadow-xl transition-all duration-300 hover:scale-105 border-2 border-electric-blue">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <Badge className="bg-red-500 text-white">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    TRENDING
                  </Badge>
                </div>
                
                <div className="space-y-4">
                  <div className="bg-neon-green bg-opacity-20 p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <span className="text-2xl mr-2">👉</span>
                      <span className="font-bold text-green-800">DO THIS:</span>
                    </div>
                    <p className="text-xl font-black text-green-900">{card.doThis}</p>
                  </div>
                  
                  <div className="bg-red-100 p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <span className="text-2xl mr-2">❌</span>
                      <span className="font-bold text-red-800">NOT THAT:</span>
                    </div>
                    <p className="text-xl font-black text-red-900">{card.notThat}</p>
                  </div>
                  
                  <div className="bg-electric-blue bg-opacity-20 p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <span className="text-2xl mr-2">💡</span>
                      <span className="font-bold electric-blue">WHY:</span>
                    </div>
                    <p className="text-lg font-bold text-blue-900">{card.why}</p>
                  </div>
                </div>
                
                {/* Share Buttons */}
                <div className="flex justify-center gap-2 mt-6">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => shareCard(card, 'whatsapp')}
                    className="hover:bg-green-500 hover:text-white"
                  >
                    WhatsApp
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => shareCard(card, 'twitter')}
                    className="hover:bg-blue-500 hover:text-white"
                  >
                    Twitter
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => shareCard(card, 'instagram')}
                    className="hover:bg-pink-500 hover:text-white"
                  >
                    Instagram
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* All Decision Cards */}
      <section className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-black mb-4">
            🎯 <span className="electric-blue">All Decisions</span>
          </h2>
          <p className="text-gray-600">Every confusion, solved.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCards.map((card, index) => (
            <React.Fragment key={card.id}>
              {/* Inline Ad after every 3 cards */}
              {index > 0 && index % 3 === 0 && (
                <div className="col-span-full">
                  <AdBanner position="inline" className="my-6" />
                </div>
              )}
              
              <Card className="hover:shadow-xl transition-all duration-300 hover:scale-105">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="bg-neon-green bg-opacity-20 p-4 rounded-lg">
                      <div className="flex items-center mb-2">
                        <span className="text-2xl mr-2">👉</span>
                        <span className="font-bold text-green-800">DO THIS:</span>
                      </div>
                      <p className="text-xl font-black text-green-900">{card.doThis}</p>
                    </div>
                    
                    <div className="bg-red-100 p-4 rounded-lg">
                      <div className="flex items-center mb-2">
                        <span className="text-2xl mr-2">❌</span>
                        <span className="font-bold text-red-800">NOT THAT:</span>
                      </div>
                      <p className="text-xl font-black text-red-900">{card.notThat}</p>
                    </div>
                    
                    <div className="bg-electric-blue bg-opacity-20 p-4 rounded-lg">
                      <div className="flex items-center mb-2">
                        <span className="text-2xl mr-2">💡</span>
                        <span className="font-bold electric-blue">WHY:</span>
                      </div>
                      <p className="text-lg font-bold text-blue-900">{card.why}</p>
                    </div>
                  </div>
                  
                  {/* Share Buttons */}
                  <div className="text-center mt-6">
                    <p className="text-sm font-bold text-gray-600 mb-2">🔥 Share this with your confused friend</p>
                    <div className="flex justify-center gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => shareCard(card, 'whatsapp')}
                        className="hover:bg-green-500 hover:text-white"
                      >
                        WhatsApp
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => shareCard(card, 'twitter')}
                        className="hover:bg-blue-500 hover:text-white"
                      >
                        Twitter
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => shareCard(card, 'instagram')}
                        className="hover:bg-pink-500 hover:text-white"
                      >
                        Instagram
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </React.Fragment>
          ))}
        </div>
      </section>

      {/* User Submission Section */}
      <section className="container mx-auto px-4 py-12 bg-gradient-to-r from-electric-blue to-neon-green">
        <div className="text-center text-white mb-8">
          <h2 className="text-3xl font-black mb-4">
            🤔 What are YOU confused about today?
          </h2>
          <p className="text-lg">Submit your confusion and we'll solve it!</p>
        </div>
        
        {!showSubmissionForm ? (
          <div className="text-center">
            <Button 
              onClick={() => setShowSubmissionForm(true)}
              className="bg-white text-electric-blue hover:bg-gray-100 font-bold text-lg px-8 py-4 bounce-animation"
            >
              🚀 Submit Your Confusion
            </Button>
          </div>
        ) : (
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-6">
              <form onSubmit={submitUserConfusion}>
                <div className="space-y-4">
                  <div>
                    <label className="block font-bold mb-2">👉 DO THIS:</label>
                    <Input
                      value={userSubmission.doThis}
                      onChange={(e) => setUserSubmission({...userSubmission, doThis: e.target.value})}
                      placeholder="e.g. Learn React"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-bold mb-2">❌ NOT THAT:</label>
                    <Input
                      value={userSubmission.notThat}
                      onChange={(e) => setUserSubmission({...userSubmission, notThat: e.target.value})}
                      placeholder="e.g. Learn Angular"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-bold mb-2">💡 WHY:</label>
                    <Input
                      value={userSubmission.why}
                      onChange={(e) => setUserSubmission({...userSubmission, why: e.target.value})}
                      placeholder="e.g. React has better job market"
                      required
                    />
                  </div>
                  <div className="flex gap-4">
                    <Button type="submit" className="bg-electric-blue hover:bg-blue-600 flex-1">
                      🔥 Submit
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowSubmissionForm(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        )}
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h3 className="text-2xl font-black mb-4 neon-green">DoThisNotThat.in</h3>
            <p className="text-lg mb-6">Made with ❤️ by Satya | Confused? We're not.</p>
            
            <div className="flex flex-wrap justify-center gap-6 mb-8">
              <a href="#" className="hover:text-neon-green transition-colors">Contact</a>
              <a href="#" className="hover:text-neon-green transition-colors">Privacy</a>
              <a href="#" className="hover:text-neon-green transition-colors">Suggest a Confusion</a>
              <a href="#" className="hover:text-neon-green transition-colors">Affiliate Disclosure</a>
            </div>
            
            <div className="text-sm text-gray-400">
              <p>© 2024 DoThisNotThat.in - Daily Dose of Clarity 💡</p>
              <p className="mt-2">Stop overthinking. Start winning. 🎯</p>
            </div>
          </div>
        </div>
      </footer>

      {/* Bottom Sticky Ad for Mobile */}
      <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden">
        <AdBanner position="bottom" className="rounded-none border-0" />
      </div>
    </div>
  )
}

export default App

