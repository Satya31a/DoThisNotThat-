// Decision Cards Data for DoThisNotThat.in
export const decisionCards = [
  {
    id: 1,
    doThis: "Freelancing",
    notThat: "9-to-5 Job",
    why: "Why build someone else's dream?",
    category: "career",
    trending: true,
    shareText: "Stop trading your freedom for fake security! 🔥"
  },
  {
    id: 2,
    doThis: "SIP",
    notThat: "FD",
    why: "FD is fear disguised as logic.",
    category: "finance",
    trending: true,
    shareText: "Your money should work harder than you do! 💸"
  },
  {
    id: 3,
    doThis: "iPhone 15",
    notThat: "Samsung S24",
    why: "You already want it. Stop lying to yourself.",
    category: "tech",
    trending: true,
    shareText: "Life's too short for Android regrets! 📱"
  },
  {
    id: 4,
    doThis: "Gym Membership",
    notThat: "Home Workout",
    why: "Your couch isn't your competition.",
    category: "fitness",
    trending: false,
    shareText: "Champions aren't made in comfort zones! 💪"
  },
  {
    id: 5,
    doThis: "MBA",
    notThat: "Startup",
    why: "Network beats hustle. Always.",
    category: "career",
    trending: true,
    shareText: "Smart people choose connections over chaos! 🧠"
  },
  {
    id: 6,
    doThis: "Bitcoin",
    notThat: "Gold",
    why: "Boomers buy gold. Winners buy Bitcoin.",
    category: "finance",
    trending: false,
    shareText: "The future doesn't wait for the fearful! ⚡"
  },
  {
    id: 7,
    doThis: "Tesla Model 3",
    notThat: "Honda Civic",
    why: "Drive the future, not the past.",
    category: "lifestyle",
    trending: false,
    shareText: "Why settle for ordinary when extraordinary exists? 🚗"
  },
  {
    id: 8,
    doThis: "Netflix",
    notThat: "Cable TV",
    why: "Cable is for people who love ads and hate choice.",
    category: "entertainment",
    trending: false,
    shareText: "Cut the cord, not your entertainment! 📺"
  },
  {
    id: 9,
    doThis: "MacBook Pro",
    notThat: "Windows Laptop",
    why: "Professionals don't compromise.",
    category: "tech",
    trending: true,
    shareText: "Your tools define your output! 💻"
  },
  {
    id: 10,
    doThis: "Rent in City",
    notThat: "Buy in Suburbs",
    why: "Opportunities don't commute.",
    category: "lifestyle",
    trending: false,
    shareText: "Location is everything in life! 🏙️"
  },
  {
    id: 11,
    doThis: "Learn Python",
    notThat: "Learn Java",
    why: "Python is the language of the future.",
    category: "tech",
    trending: false,
    shareText: "Code your way to freedom! 🐍"
  },
  {
    id: 12,
    doThis: "Spotify Premium",
    notThat: "Free Spotify",
    why: "Your time is worth more than ₹119/month.",
    category: "entertainment",
    trending: false,
    shareText: "Life's too short for ads between songs! 🎵"
  },
  {
    id: 13,
    doThis: "Start a Blog",
    notThat: "Stay Silent",
    why: "Your voice matters. Use it.",
    category: "career",
    trending: false,
    shareText: "The world needs your unique perspective! ✍️"
  },
  {
    id: 14,
    doThis: "Invest in Yourself",
    notThat: "Save Every Penny",
    why: "You are your best investment.",
    category: "finance",
    trending: false,
    shareText: "The best ROI is always on yourself! 📈"
  },
  {
    id: 15,
    doThis: "Travel Solo",
    notThat: "Wait for Friends",
    why: "Your dreams don't need company.",
    category: "lifestyle",
    trending: false,
    shareText: "Adventure waits for no one! ✈️"
  }
];

export const trendingCards = decisionCards.filter(card => card.trending);

export const categories = [
  { id: 'all', name: 'All', emoji: '🔥' },
  { id: 'career', name: 'Career', emoji: '💼' },
  { id: 'finance', name: 'Finance', emoji: '💰' },
  { id: 'tech', name: 'Tech', emoji: '📱' },
  { id: 'lifestyle', name: 'Lifestyle', emoji: '🌟' },
  { id: 'fitness', name: 'Fitness', emoji: '💪' },
  { id: 'entertainment', name: 'Entertainment', emoji: '🎬' }
];

export const motivationalQuotes = [
  "Confused minds make poor decisions. Clear minds make millions. 💰",
  "While you're thinking, someone else is doing. 🚀",
  "Indecision is a decision. Usually the wrong one. ⚡",
  "Smart people don't overthink. They just pick the winner. 🧠",
  "Your future self is judging your current choices. Choose wisely. 👁️"
];

export const shareMessages = {
  whatsapp: "Check out DoThisNotThat.in - finally someone who tells it like it is! 🔥",
  instagram: "When you're confused AF but DoThisNotThat.in has your back 💯 #DecisionMaking #LifeHacks",
  twitter: "Stop overthinking. Start winning. DoThisNotThat.in knows what's up 🎯"
};

